
// Simple Service Worker (offline caching placeholder)
self.addEventListener('install', function(event) {
  event.waitUntil(caches.open('v1').then(cache => cache.addAll(['index.html'])));
});
self.addEventListener('fetch', function(event) {
  event.respondWith(caches.match(event.request).then(response => response || fetch(event.request)));
});
